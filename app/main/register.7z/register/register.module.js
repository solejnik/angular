angular.module('app.register', ['ngRoute','app.main','app.register.templates','ui.bootstrap'])
    .config(function ($routeProvider) {
        'use strict';
        $routeProvider.when('/main/register', {
			templateUrl: 'main/register/register.html', controller: 'RegisterController'});
		
    });


