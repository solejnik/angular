angular.module('app.register').factory('RegisterRestService', function ($http ) {
    'use strict';

    return {
        register: function (registerData) {
			var firstName = registerData.firstName;
			var lastName = registerData.lastName;
			var email = registerData.email;
			var password = registerData.password;
            return $http.post('/web/register', {params: {firstName:firstName, lastName:lastName, email:email, password:password}});
        }
    };
});