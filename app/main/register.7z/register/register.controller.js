angular.module('app.register').controller('RegisterController', function ($scope, RegisterRestService) {
    'use strict';


	 $scope.registerData = {
		 firstName : '1',
		 lastName :'2',
		 email :'3',
		 password :'4'
	 };
	 
	 $scope.reEmail = '';
	 $scope.rePassword = '';
	 
	 
     $scope.register = function () {
        AuthenticationRestService.search($scope.registerData).then(function (response) {
			alert();
		}, function () {
            alert('Faiure!!!');
        });
    };


});


